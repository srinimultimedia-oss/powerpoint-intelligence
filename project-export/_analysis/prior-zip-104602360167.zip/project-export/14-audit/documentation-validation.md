# Documentation validation method and results

## Executed export checks

The parent validator checks required-file presence/nonempty content, everyexplicit source-file/line-range reference, internalfilelinks, Mermaidfence/type structure, unique feature IDs/requiredfields, module/source/test assignments, source hashes/review rows, portablefiletypes, archive hashes/content exclusion and source preservation. A separate contractexample check parsed twoJSON examples and validated theplannedAI sample against the actualAJV schema; this is not live AI execution.

Negative controls exercise invalidsource references, a missinglink, unsupporteddiagramtype and syntheticsecret-marker detection. A knownvalidcontrol proves rejectionisnotacatch-all. Source-prose meaning is editoriallyreviewed; file/line validation alone cannot prove behavior. LocalMermaidparser/runtime was notfound; structuralvalidation is not full syntax/render validation.

Validation JSON/transcripts and exact metriccounts are linked below after the final pass. The master includes copied diagrams/source citations, so occurrencecounts exceed unique designs/references. Parent/leaf outputs are independentlychecked; none is accepted solelybecauseitsauthorreported success.

Application preservation baseline covers30,300 regular files outside export. One historicaltestjunction is explicitly inventoried and notfollowed. Currentvalidation createsoutputs/tempbinaryonlyinsideexport; portableZIPexcludeshelpercode/binaries/private configuration/sourceassets. All runtime/scan/installation omissions are documented separately in test-results and assumptions.

## Final structural measurements

- Markdowndocuments:126; required paths:81/81.
- Source reference occurrences:6012, distinctsource/ranges:1662; allvalidfile/ranges.
- Internal file link targets checked:563; zeromissing.
- Mermaid blocks:64; unique designs:33; all structurally recognized. Fullparser/renderchecks:0/33, unavailable locally.
- Current semantic code-file accounting:204/204withreviewqualifications;46 module designs;190 featureentries;71 test source files.
- Source preservation:30300regularfiles unchanged; no added/removed/modified files outside export.

See [full validation](parent-validation-all.json), [metrics](completion-metrics.json), [contract examples](contract-example-validation.log), [preservation](source-preservation.json) and [evidence](evidence-traceability.csv). Counterexample controls and secret/archivechecks are recorded separately; no source/runtime result is inferred from a structural pass.
