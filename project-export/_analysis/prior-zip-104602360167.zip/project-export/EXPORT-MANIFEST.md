# Export manifest

Application: **NexWave / PowerPoint Intelligence**. Repository: `C:/Srini/powerpoint-intelligence/powerpoint-intelligence`. Commit baseline: `ffaec352cbdca666f69f3c402d334108e4115933`. Generated UTC:2026-11-13T06:36:33.781730+00:00 (13-Nov-2026Asia/Dubai). Exportversion1.0; destination: `project-export/`.

All81requiredfiles are supplied, plus46module designs, boundedinterface/native/event appendices, CSV/JSON source/review/test inventories and validation evidence. [Index](DOCUMENTATION-INDEX.md) provides the completeMarkdownlist; [portable-file inventory](14-audit/export-file-inventory.csv) records everyselectedfile/size/hash. Exactsourcehashes and exclusions are in the repositoryinventory/review manifests.

Coverage:204/204authoredcodefiles reviewed at explicit levels;339 relevanttextfiles structurallyinspected;46/46modules;190/190featureentries;12/12declaredinterfacegroups (oneplanned);71/71testsourcefiles mapped. Relatedtestcandidates cover190/190featureentries and are not instrumented coverage. Fullrepositorydiscovery30,301 records includes30,300 regularfiles and1nontraversedreparseentry. Source bytebaselineunchanged. See [completeness](15-deliverables/DOCUMENTATION-COMPLETENESS-REPORT.md) and [validation](14-audit/documentation-validation.md).

Currenttests:229assertionspass, TypeScriptnoEmitpasses,50 PowerShellfilesparse. No currentnativeOffice/signed installation/externalservices/scannerpass. Mermaidstructuralchecksareperformed; full parser/render unavailable. Exact finalreferences/diagram/linkcounts are recorded in validation JSON/report, not guessed here.

OpenAPI is intentionally omitted as an executable specification because noHTTPserver/routes exist; [reason](07-api-design/openapi/README.md). AIarchitecture is profile/schema/planning, not live deployment. V3contracts are authoredbutnotcompiled. Newsecurity/testgaps remain recommendations; historicalCheckmarxclearance is not asserted.

PortableZIP: [PowerPoint-Intelligence-NexWave-Technical-Design.zip](15-deliverables/PowerPoint-Intelligence-NexWave-Technical-Design.zip). No applicationcode/dependencies/private configuration/credentials/binaries/licensed template assets are included. Local_analysis, .unlazy, authoring.py/.mjs/.ps1 helpers andtemporarytestoutputs are excluded. Repository-relative source paths/lines remain textual citations, not copied source files. Diagram/codecontractexamples are documentation, not source distribution.

Checksums: [DOCUMENT-CHECKSUMS.sha256](15-deliverables/DOCUMENT-CHECKSUMS.sha256) hashes selecteddocument/data files; it excludes itself andZIP/hashreceipt to avoid cycles. [ZIP checksum](15-deliverables/PowerPoint-Intelligence-NexWave-Technical-Design.zip.sha256) and [archive verification](14-audit/archive-validation.json) record the finishedarchive. The archive excludes itself/previousarchives and its external audit/checksumreceipts.

Overall status: requested documentationpackage delivered with explicit limitations, not production or securitycertification. No prior exportexisted; no existing applicationfile was replaced. Subsequent regeneration shouldpreservethisbaselineoruseaversionedexportfolder.
